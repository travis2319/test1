export { default as Navbar } from "./Navbar";
export { default as Searchbar } from "./Searchbar";
export { default as Details } from "./Details";
export { default as Footer } from "./Footer";
